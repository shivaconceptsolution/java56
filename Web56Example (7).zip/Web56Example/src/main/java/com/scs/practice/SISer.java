package com.scs.practice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SISer")
public class SISer extends HttpServlet {
	
  
    public SISer() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  PrintWriter out = response.getWriter();
		  response.setContentType("text/html");
		  out.write("<form action='' method='post'>");
		  out.write("<input type='text' name='txtp' placeholder='Enter p' /><br><br>");
		  out.write("<input type='text' name='txtr' placeholder='Enter r' /><br><br>");
		  out.write("<input type='text' name='txtt' placeholder='Enter t' /><br><br>");
		  out.write("<input type='submit' name='btnsubmit' value='Calculate SI' /><br>");
		  out.write("</form>");
		  
		  if(request.getParameter("q")!=null)
		  {
			  out.print("RESULT IS " +request.getParameter("q"));
		  }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		float p,r,t,si;
		p = Float.parseFloat(request.getParameter("txtp"));
		r = Float.parseFloat(request.getParameter("txtr"));
		t = Float.parseFloat(request.getParameter("txtt"));
		si=(p*r*t)/100;
	//	RequestDispatcher req = request.getRequestDispatcher("SISer");
	//	req.forward(request, response);
		response.sendRedirect("SISer?q="+si);
		// PrintWriter out = response.getWriter();
		//out.print("result is "+si);
	}

}
