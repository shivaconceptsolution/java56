package com.scs.practice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/addition")
public class Addition extends HttpServlet {
 public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException
 {
	 int a = Integer.parseInt(request.getParameter("txtnum1"));
	 int b = Integer.parseInt(request.getParameter("txtnum2"));
	 AddLogic obj = new AddLogic();
	 int c = obj.addition(a, b);
	 PrintWriter out = response.getWriter();
	 out.write("Result is "+c);
 }
}
