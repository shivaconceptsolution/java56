package com.scs.practice;

public class AddLogic {
   int addition(int a,int b)
   {
	   
		int c = a+b;
		return c;
		
   }
}
