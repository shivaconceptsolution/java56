package com.scs.practice;

public class CheckPrimeNum {
	int num,i;
	String s = "";
    void accept(int num)
    {
    	this.num=num;
    	
    }
    void checkPrime()
    {
    	for(i=2;i<num;i++)
    	{
    		if(num%i==0)
    		{
    			s = "NOT Prime";
    			break;
    		}
    	}
    	if(num==i)
    	{
    		s = "Prime";
    	}
    }
    String displayResult()
    {
    	return s;
    	
    }
    
}
