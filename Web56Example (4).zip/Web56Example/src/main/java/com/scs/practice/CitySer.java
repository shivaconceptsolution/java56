package com.scs.practice;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class CitySer
 */
@WebServlet("/CitySer")
public class CitySer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
			Statement st = conn.createStatement();
			int x = st.executeUpdate("insert into city(cityid,cityname) values('"+request.getParameter("txtcityid")+"','"+request.getParameter("txtcityname")+"')");
			if(x!=0)
			{
				response.sendRedirect("viewcity.jsp?q=City Added Successfully");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 

	}

}
