﻿using System;
using System.Collections.Generic;

namespace entityframeworkexample.Models.DB;

public partial class Student
{
    public int Rno { get; set; }

    public string? Sname { get; set; }

    public string? Branch { get; set; }

    public int? Fees { get; set; }
}
