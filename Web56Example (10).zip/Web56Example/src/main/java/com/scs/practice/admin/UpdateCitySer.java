package com.scs.practice.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scs.helper.Datahelper;

/**
 * Servlet implementation class UpdateCitySer
 */
@WebServlet("/UpdateCitySer")
public class UpdateCitySer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 try {
				Datahelper.connection();
				int x = Datahelper.dmlOperation("update city set cityname='"+request.getParameter("txtcityname")+"' where cityid='"+request.getParameter("txtcityid")+"'");
				if(x!=0)
				{
					response.sendRedirect("admin/viewcity.jsp?q=update Successfully");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
