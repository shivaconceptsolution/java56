package com.scs.practice.users;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scs.helper.Datahelper;

/**
 * Servlet implementation class UseRegSer
 */
@WebServlet("/UseRegSer")
public class UseRegSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try
		{
		Datahelper.connection();
		int x =Datahelper.dmlOperation("insert into registration(username,password,email,mobileno) values('"+request.getParameter("txtuname")+"','"+request.getParameter("txtpass")+"','"+request.getParameter("txtemail")+"','"+request.getParameter("txtmobile")+"')");
		if(x!=0)
		{
			response.sendRedirect("users/registration.jsp?q=Registration Successfully");
		}
		}
		catch(Exception ex)
		{
			out.print(ex.getMessage().toString());
		}
	}

}
