package com.scs.practice;

import java.io.IOException;
import java.sql.Time;
import java.time.Duration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieSer
 */
@WebServlet("/CookieSer")
public class CookieSer extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cookie obj = new Cookie("cookieone",request.getParameter("txt"));
		response.addCookie(obj);
		obj.setMaxAge(10000);
		response.sendRedirect("viewcookiedata.jsp");
	}

}
