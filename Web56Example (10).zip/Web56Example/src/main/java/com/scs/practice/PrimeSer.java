package com.scs.practice;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PrimeSer
 */
@WebServlet("/PrimeSer")
public class PrimeSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CheckPrimeNum obj = new CheckPrimeNum();
		obj.accept(Integer.parseInt(request.getParameter("txtnum")));
		obj.checkPrime();
		String s = obj.displayResult();
		response.sendRedirect("primedesign.jsp?q="+s);
	}

}
