package com.scs.practice.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class UploadSer
 */
@WebServlet("/UploadSer")
public class UploadSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		MultipartRequest m=new MultipartRequest(request,getServletContext().getRealPath("/")+"upload");
		out.print(getServletContext().getRealPath("/"));
        out.print("successfully uploaded");
        out.print(m.getFilesystemName("file")+"<br>");
		out.print(m.getContentType("file")+"<br>");
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
		Statement st = con.createStatement();
		int x = st.executeUpdate("insert into tbl_upload(imgpath) values('"+m.getFilesystemName("file")+"')");
		if(x!=0)
		{
			response.sendRedirect("fileupload.jsp");
			//out.print("File uploaded Successfully");
		}
		con.close();
		}
		catch(Exception ex)
		{
			
		}
	}

}
