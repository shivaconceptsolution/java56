package com.scs.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Datahelper {
  static Connection conn;
  static Statement st;
  public static void connection() throws Exception
  {
	    Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
		st = conn.createStatement();
  }
  
  public static ResultSet selectData(String query) throws Exception
  {
	  return st.executeQuery(query);
  }
  public static int dmlOperation(String query) throws Exception
  {
	  return st.executeUpdate(query);
  }
  public static void closeConnection() throws Exception
  {
	  conn.close();
  }
  
  
}
